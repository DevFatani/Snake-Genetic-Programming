package utilities;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Method;

/**
 * User: Simon
 * Date: 10-Dec-2007
 * Time: 23:56:27
 */
public class ProcButton extends JButton implements ActionListener {
    // String name;
    Object parent;
    Class[] argts; // dummy array of argument types
    Object[] args; // dummy array of arguments
    Method method;

    public ProcButton(String name, Object parent) {
        this(name, name, parent);
    }

    public ProcButton(String procName, String buttonName, Object parent) {
        super(buttonName);
        try {
            addActionListener(this);
            // this.name = name;
            this.parent = parent;
            argts = new Class[0];
            args = new Object[0];
            method = parent.getClass().getMethod(procName, argts);
        }
        catch (Exception e) {
            System.out.println(e);
        }
    }

    public void actionPerformed(ActionEvent e) {
        // System.out.println(e);
        try {
            method.invoke(parent, args);
        }
        catch (Exception ex) {
            System.out.println(ex);
        }
    }
}

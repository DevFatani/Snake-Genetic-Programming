package utilities;

import javax.swing.*;
import java.awt.*;
import java.lang.reflect.Method;

public class AutoButtonPanel extends JPanel {

    // Object parent;
    static String PATTERN = "button";
    String pattern;

    public void foo() {
        System.out.println("JJJJ");
    }

    public AutoButtonPanel(Object parent) {
        this(parent, PATTERN);
    }

    public AutoButtonPanel(Object parent, String pattern) {
        this.pattern = pattern;
        setLayout(new FlowLayout());

        // add(new Label("Something"));

        Class c = parent.getClass();
        Method[] m = c.getMethods();

        for (int i = 0; i < m.length; i++) {
            String name = m[i].getName();
            // System.out.println(name);
            int pos;
            if ((pos = name.indexOf(pattern)) != -1) {
                add(new ProcButton(name, name.substring(pos + pattern.length()), parent));
            }
        }
    }

}


package utilities;

import javax.swing.*;
import java.awt.*;


/**
 * This is a vertical version of the bar chart;
 *  could have built it into the same class (or had an abstract superclass
 *  then two concrete classes for horzontal and vertical bar charts
 */
public class VBarChart extends JComponent {

    static int w = 100, h = 400;

    double[] x;
    Dimension d;
    Color fg = new Color( 20, 20, 150 );
    Color bg = new Color( 200, 200, 255 );
    Color highlight = Color.red;
    // static int gap = 2;

    public static void main(String[] args) {
        double[] x = { 0, 1, 0.5, 0.3, 0.2, 0.5, 0.0, 0.8, 0.3 };
        VBarChart bc = new VBarChart();
        new JEasyFrame( bc , "Bar Chart Test", true );
        bc.update( x );
    }


    public VBarChart() {
        this(new Dimension(w, h) );
    }

    public VBarChart(Dimension d) {
        this.d = d;
    }

    public VBarChart(Dimension d, double[] x) {
        this.d = d;
        this.x = x;
    }

    public void update(double[] x) {
        this.x = x;
        repaint();
    }

    public void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        Dimension size = getSize();
        g2.setColor( bg );
        g2.fillRect( 0, 0, size.width, size.height );

        if (x != null) {
            g2.translate(0 , size.height);
            g2.scale( 1 , -1 );
            int n = x.length;
            // assume all in range zero to one
            // double max = VecMat.max( x );
            double max = max( x );
            int barWidth = size.height / n;
            int gap = barWidth / 10;
            for (int i = 0; i < x.length; i++) {
                int w = (int) (size.width * (x[i] / max) );
                Color c = x[i] == max ? highlight : fg;
                g2.setColor( c );
                // g2.fill3DRect( gap + i * barWidth, 0, barWidth-gap, h, false );
                g2.fill3DRect( 0, gap + i * barWidth, w, barWidth-gap, true );
            }
        }
    }

    public Dimension getPreferredSize() {
        return d;
    }

    public double max(double[] vec) {
        if (vec.length == 0) return 0;
        double m = vec[0];
        for (double x : vec) {
            m = Math.max(m, x);
        }
        return m;
    }
}
package utilities;

public class VecUtil {

    public static void main(String[] args) {
        double[] v = new double[]{1, 10, 100, -50};
        System.out.println("Min: " + min(v));
        System.out.println("Max: " + max(v));
    }

    public static double min(double[] v) {
        double res = Double.MAX_VALUE;
        for (double x : v) {
            res = Math.min(x, res);
        }
        return res;
    }

    public static double max(double[] v) {
        double res = Double.MIN_VALUE;
        for (double x : v) {
            res = Math.max(x, res);
        }
        return res;
    }



}

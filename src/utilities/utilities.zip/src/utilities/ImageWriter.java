package utilities;

import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.OutputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.File;


public class ImageWriter {

    public static void main(String[] args) {
        String[] sa = ImageIO.getReaderFormatNames();
        for (String s : sa) {
            System.out.println(s);
        }
    }

    public static void writePNG(BufferedImage im, String path) throws Exception {
        ImageIO.write(im, "png", new File(path));
    }

    public static void writeJpeg(BufferedImage image, String path) throws Exception {
        OutputStream out = new BufferedOutputStream(new FileOutputStream(path));
        JPEGImageEncoder encoder =
                JPEGCodec.createJPEGEncoder(out);
        JPEGEncodeParam param =
                encoder.getDefaultJPEGEncodeParam(image);
        param.setQuality(0.95f, true);
        encoder.encode(image, param);
        out.close();
    }

}

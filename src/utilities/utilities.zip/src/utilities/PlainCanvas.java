package utilities;

import java.awt.*;

public class PlainCanvas extends Canvas {
    int x;
    int y;

    public PlainCanvas(Color color, int x, int y) {
        this.x = x;
        this.y = y;
        setBackground(color);
        setSize(x, y);
    }
    /*
    public Dimension getPreferredSize() {
      return new Dimension(x, y);
    }
    */
}


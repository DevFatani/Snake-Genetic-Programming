package utilities;

import java.io.*;
import java.util.Random;

/*

 Wish to add the ability to efficiently deal a few cards
 and keep them in a temporary hand.

*/

public class CardDeck implements Serializable {
    int size;
    int n;
    int[] cards;
    int[] dealt; // card already dealt

    Random r;

    public CardDeck(int size) {
        this(size, new Random());
    }

    public CardDeck(int size, Random r) {
        this.size = size;
        this.r = r;
        cards = new int[size];
        dealt = new int[size];
        resetDeck();
    }

    public void resetDeck() {
        for (int i = 0; i < size; i++)
            cards[i] = i;
        n = size;
    }

    public void orderDeck() {
        for (int i = 0; i < size; i++)
            dealt[i] = i;
        n = size;
    }

    public int getCard() {
        if (n > 0) {
            int next = r.nextInt(n); // RandInt.range(n); // pick a random card out
            //System.out.println(next);
            //Wait.Input();
            int card = cards[next];
            cards[next] = cards[n - 1];
            n--;
            return card;
        } else {
            // throw new RuntimeException("Empty Card Deck!");
            resetDeck();
            return getCard();
        }
        // return -1;
    }

    public void removeCard(int card) {
        // only to be used with an unshuffled deck
        // and each card only to be got once
        if (cards[card] == card) {
            cards[card] = cards[n - 1];
            n--;
        } else {
            throw new RuntimeException("Card " + cards[n] + " does not match " + n);
        }
    }

    public void putCard(int i) {
        if (n < cards.length)
            cards[n++] = i;
    }

    public void shuffle() {
        resetDeck();
        for (int i = 0; i < size; i++)
            dealt[i] = getCard();
    }

    public int card(int i) {
        return dealt[i];
    }

    public String toString() {
        String res = "";
        for (int i = 0; i < size; i++)
            res += card(i) + "\n";
        return res;
    }

    public static void main(String[] args) {

        CardDeck d = new CardDeck(6);
        //Wait.Input();

        System.out.println(d);

        for (int i = 0; i < 6; i++)
            System.out.println(d.getCard());


        d.shuffle();
        System.out.println(d);

    }
}
